import { HeaderStyle } from "./HeaderStyle.style";
import LogoImg from '../../assets/Edvaldo Catimba.jpg'
import { TiHome } from "react-icons/ti";
import { GiClaymoreExplosive } from "react-icons/gi";
import { IoBarChartOutline } from "react-icons/io5";
import { IoMdContact } from "react-icons/io";
import { GiBookshelf } from "react-icons/gi";
const Header = () => {

    return(
        <HeaderStyle>
            <img className="img-logo" src={LogoImg} alt="Logo" />
            <ul className="menu">
                <li className="item">
                    <TiHome className="ico-m" size={30} /> <span>Home</span>
                </li>
                <li className="item">
                    <IoBarChartOutline className="ico-m" size={30} /> <span>Sobre</span>
                </li>
                <li className="item">
                    <GiBookshelf className="ico-m" size={30} /> <span>Habilidades</span>
                </li>
                <li className="item">
                    <IoMdContact className="ico-m" size={30} /> <span>Contacto</span>
                </li>
            </ul>
        </HeaderStyle>
    )
}

export default Header;