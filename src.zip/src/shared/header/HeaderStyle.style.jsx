import styled from 'styled-components';


export const HeaderStyle = styled.div`
padding: 20px 60px;
display: flex;
justify-content: space-between;
align-items: center;
background-color: #161F2D;
flex-wrap: wrap;


.img-logo{
    border-radius: 50%;
    width: 60px;
    border: 2px solid black;
}

.menu{
    display: flex;
    list-style: none;
    gap: 50px;
    align-items: center;
    flex-wrap: wrap;
}
.menu li span{
    font-size: 1.9rem;
    color: white;
    font-weight: 800;
    
}
.menu li span:hover{
    text-shadow: 1px 1px 30px #37a2e9;
    cursor: pointer;
    transition: .6s;
}
.menu li{
    display: flex;
    align-items: center;
    gap: 5px;
    color: white;
}


`