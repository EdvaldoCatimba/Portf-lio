import { BodyStyle } from "./Body.Style";
import Home from "./Home/Home";

const Body = () => {

    return(
        <BodyStyle>
            <Home />
        </BodyStyle>
    )
}

export default Body;