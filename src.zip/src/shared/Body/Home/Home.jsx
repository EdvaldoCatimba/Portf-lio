import { HomeStyle } from "./Home.Style";
import IMG from '../../../assets/Desktop-Pancada_Educa.png'
const Home = () => {

    return(
        <HomeStyle>
            <img className="imgUser" src={IMG} alt="Imagem do autor" />
            <div className="text">
                <p>Oi, Sou o <br /> <span>Edvaldo Catimba</span>, <br /> Desenvolvedor Front-End</p>
            </div>
        </HomeStyle>
    )
}

export default Home;