import styled from "styled-components";


export const HomeStyle = styled.div`
display: flex;
align-items: center;
justify-content: space-around;
flex-wrap: wrap;


.imgUser{
    width: 300px;
    border-radius: 50%;
    transform: translate(-10%, -10%);
    animation: circular-motion 4s linear infinite;
}

.text p{
    font-size: 2.5rem;
    color: white;
    font-weight: 700;
}
.text p span{
    font-size: 3rem; 
    font-weight: bolder;
    color: #1F2937;
    animation:Text 4s normal infinite;
}


@keyframes Text {
    0%{
        color: white;
        text-shadow: none;
    }
    50%{
        text-shadow: 1px 2px 10px #03bcf4,
        3px 20px 20px #03bcf4
        20px 20px 40px #03bcf4
        0 0 80px #03bcf4;
    }
    100%{
        color: white;
        text-shadow:  1px 1px 60px #37a2e9;
       
    }
}
@keyframes circular-motion {
            0% {
                transform: rotate(0deg) translateX(20px) rotate(0deg);
            }
            100% {
                transform: rotate(360deg) translateX(20px) rotate(-360deg);
            }
    }
`