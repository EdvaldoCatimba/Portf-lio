import styled from "styled-components";

export const BodyStyle = styled.div`
padding: 20px 60px;
padding-top: 80px;
background-color: #1F2937;

`